print ('---------------------------------WELCOME----------------------------')

print  ('      Bagaimana Kabar Kakak Semua? Semoga Selalu Semangat ya!     ')

print (' Yuk, kita belajar Bahasa, dengan memahami kosa kata Bahasa Inggris dan Bahasa Arab')

Translator = input 
Bahasa = input ('Silakan pilih Bahasa yang ingin kamu terjemahkan??\n1.Indonesia-Inggris\n2.Indonesia-Arab?').lower()
print('silakan kamu masukkan kata yang ingin kamu terjemahkan')
true = 'input != stop'

KataYangDicari = "kata-kata"

while (true) :
    KataYangDicari = input("Masukkan kata yang dicari: ").lower()
    
    if KataYangDicari == 'stop':
        print("^.^Terima Kasih..")
        break
    Hitung = 0

    if Bahasa == '1':
        listKata = "listKataInggris"
        fileIndonesia = open("list_indonesia.txt","r")
        fileInggris = open("list_inggris.txt","r")
        listKata = fileIndonesia.readlines()
        listKataInggris = fileInggris.readlines()
        Hitung = -1
        index = 0
        for index, elemen in enumerate(listKata):
            item = elemen.rstrip().lower()
            if item == KataYangDicari:
                Hitung = index
                break
        
        index = index + 1
        print(listKataInggris[Hitung])
    
    
    else : 
        listKata = "listKataArab"
        fileIndonesia = open("list_indonesia.txt","r")
        fileArab = open("list_arab.txt","r")
        listKata = fileIndonesia.readlines()
        listKataArab = fileArab.readlines ()
        Hitung = -1
        index = 0
        for index, elemen in enumerate(listKata):
            item = elemen.rstrip().lower()
            if item == KataYangDicari:
                Hitung = index
                break
        
        index = index + 1
        print(listKataArab[Hitung])
    
    

    



    




    